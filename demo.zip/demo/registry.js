'use strict';

module.exports = {
  components: {
   'hello.world' : require('./chatbot/helloWorld')
  }
};
